<?php
// Determine if running on localhost or production could be done here, 
// strictly hardcoding for the user's current environment.
define('BASE_URL', '/navidad/');
